package library;


import java.time.LocalDate;
 

public class BookLoan {
    private final int id, bookId, memberId;
    private final LocalDate borrowDate;
    public int booksOnLoan;
    
    
    public BookLoan(int id, int bookId, int memberId, LocalDate BorrowDate){
        this.id = id;
        this.bookId = bookId;
        this.memberId = memberId;
        this.borrowDate = LocalDate.now();
    }

    public void showLoan(){
        System.out.printf("%d %d %d %s \n",this.id,this.bookId,this.memberId,this.borrowDate.toString());
    }
	public void borrowBook(){
		
		
	}
	
}